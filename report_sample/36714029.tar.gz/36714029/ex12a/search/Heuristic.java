package ex12a.search;

public interface Heuristic {
	float eval(State s);
}
