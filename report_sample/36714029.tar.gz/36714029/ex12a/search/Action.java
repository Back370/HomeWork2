package ex12a.search;

public interface Action {
	float cost();
}
