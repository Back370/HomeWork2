#include<stdio.h>
int main(void)
{
    int b;
    double a; 

    a = b = 2.5;

    printf("aの値:%f" ,a);
    printf("bの値:%d" ,b);
}