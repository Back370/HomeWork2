#include<stdio.h>
int main(void)
{
    printf("学籍番号: 36714029 ");
    printf("氏名：　遠藤　裕人");
}